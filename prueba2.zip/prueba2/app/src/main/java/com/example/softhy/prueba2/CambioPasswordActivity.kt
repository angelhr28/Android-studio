package com.example.softhy.prueba2

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.Snackbar
import android.widget.LinearLayout
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_cambio_password.*

class CambioPasswordActivity : AppCompatActivity() {
    lateinit var layuot_Pass: LinearLayout
    lateinit var usuario: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cambio_password)
        val confirmar = cambioConfirmado
        usuario = lbl_nameCambio
        intent.extras.apply {
            usuario.text = getString("NOMBRE")

         }

        confirmar.setOnClickListener{
            var intent = Intent(this , VistaLoginActivity::class.java)
            startActivity(intent)
        }
    }
}

package com.example.softhy.prueba2

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.Snackbar
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.ViewAnimator
import kotlinx.android.synthetic.main.activity_mensajeria.*
import android.app.Activity



@Suppress("NULLABILITY_MISMATCH_BASED_ON_JAVA_ANNOTATIONS", "RECEIVER_NULLABILITY_MISMATCH_BASED_ON_JAVA_ANNOTATIONS")
class MensajeriaActivity : AppCompatActivity() {

    lateinit var nombre: TextView
    lateinit var layout: LinearLayout

    companion object {
        val EXTRA_NOMBRE = /*this::class.java.name + */"ANGEL HR "
        val EXTRA_PASS = "Pass"
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mensajeria)
        layout = layout_mensajeria
        nombre = lbl_user_message
        val nombreFinal = nombre.text
        val confirmar = cambioContra
        val enviar = enviar
        val boton3 = BOTON3
        confirmar.setOnClickListener {
            var intent = Intent(this , CambioPasswordActivity::class.java)
            intent.putExtra(MensajeriaActivity.EXTRA_NOMBRE, EXTRA_NOMBRE   )
            startActivity(intent)
        }

        intent.extras.apply {
            nombre.text = this.getString(VistaLoginActivity.EXTRA_NOMBRE)
        }
        enviar.setOnClickListener{
            var intent2 = Intent(this ,MainActivity::class.java )
            startActivity(intent2)
        }

            var resultado:String = "ansdjnaskjd"
            boton3.setOnClickListener {
                val returnIntent = Intent()
                returnIntent.putExtra("result", resultado)
                setResult(Activity.RESULT_OK, returnIntent)
                finish()
            }

    }
}

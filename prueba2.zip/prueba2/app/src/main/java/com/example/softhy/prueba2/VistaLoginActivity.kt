package com.example.softhy.prueba2

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_vista_login.*
import android.app.Activity
import android.R.attr.data
import android.annotation.SuppressLint
import android.widget.TextView


class VistaLoginActivity : AppCompatActivity() {

    companion object {
        val EXTRA_NOMBRE = /*this::class.java.name + */"ANGEL HR "
        val EXTRA_PASS = "Pass"
    }

    data class Personas (var usuario:String,var password:String )

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vista_login)
        var boton = buttonLogin
        var boton2 = boton2
        var name = lbl_cliente
        var password = lbl_password
        var cambio = compilaploox
        name.setText("ANGEL HR ")
        var cliente = Personas(name.text.toString() , password.text.toString())

        boton.setOnClickListener {
            var intent = Intent(this, MensajeriaActivity::class.java)

        intent.putExtra(VistaLoginActivity.EXTRA_NOMBRE, EXTRA_NOMBRE)
            startActivity(intent)
        }
        boton2.setOnClickListener {
            cambio.setText("Que mira prro")
        }
        cambio.setOnClickListener {
            val i = Intent(this, MensajeriaActivity::class.java)
            startActivityForResult(i, 1)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode === 1) {
            if (resultCode === Activity.RESULT_OK) {
                val result = data!!.getStringExtra("result")
            }
            if (resultCode === Activity.RESULT_CANCELED) {
                //Write your code if there's no result
            }
        }

    }



}

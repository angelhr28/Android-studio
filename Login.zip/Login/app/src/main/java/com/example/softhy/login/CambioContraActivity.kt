package com.example.softhy.login

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_cambio_contra.*
import android.app.Activity
import kotlinx.android.synthetic.main.activity_datos.*


class CambioContraActivity : AppCompatActivity() {
    data class Datos(var contrase:String, var  contraN:String , var contraR:String)

    companion object {
        val EXTRA_MSG_RESULT = "mensaje"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cambio_contra)
        var contra1 =lbl_passwordAntigua
        var contraNueva=lbl_passwordNueva
        var contraRepetir = lbl_passwordRep
        var contraAnt = " "
        intent.extras.apply {

            contraAnt=this.getString(DatosActivity.PASSWORD)
        }
        val boton = bt_Confirmar
        boton.setOnClickListener {

            var Guardar = Datos(contra1.text.toString(),contraNueva.text.toString(),contraRepetir.text.toString())
            cambio(Guardar.contrase,contraAnt,Guardar.contraN,Guardar.contraR)
        }

    }

    fun cambio (contra:String,comparar:String,contraNueva:String,contraRepetir:String){
        if (contra.equals(comparar,true) && contraRepetir.equals(contraNueva,true)) {
            comparar == contraNueva
            val returnIntent = Intent()
            returnIntent.putExtra(CambioContraActivity.EXTRA_MSG_RESULT, "La contrase fue cambiada con exito")
            setResult(Activity.RESULT_OK, returnIntent)
            finish()
        }else {
            Toast.makeText(this, "La contrase es incorrecta ", Toast.LENGTH_SHORT).show()
        }

    }

}

package com.example.softhy.login

import android.app.Activity
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_botones.*

class BotonesActivity : AppCompatActivity() {
    companion object {
        var mensaje = "hola"
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_botones)
        val boton = bt_mensaje
        boton.setOnClickListener {
            val returnIntent = Intent()
                returnIntent.putExtra(BotonesActivity.mensaje, "hola que pex q haces")
                setResult(Activity.RESULT_OK,returnIntent)
                finish()
        }
    }
}

package com.example.softhy.login
import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import com.example.softhy.login.R.id.lbl_user
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : AppCompatActivity() {
    data class Datos(val nombre:String = "angel",val apellido:String = "robles",val user:String ,val password:String )
    companion object {
        val KEY = "KEY"
        val KEY2 = "KEY2"
        val KEY3 = "KEY3"
        val KEY4 = "KEY4"

        val nombre:String = "angel"
        val apellido:String = "robles"
        val usuario:String = "angel"
        lateinit var layout : LinearLayout
        var password1 ="123456"
    }
        override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
            var nick = lbl_user
            var contra = lbl_password
            var botoLogin = bt_login
            var nuevo: String
            var c = 0
            intent.extras.apply {
                nuevo = "nuevo"
            }
            botoLogin.setOnClickListener {
                var Persona1= Datos("angel", "robles", nick.text.toString() ,contra.text.toString())
                if(c == 0){
                    validacion(Persona1.user,Persona1.password,botoLogin)
                    c++
                }else {
                    password1 == nuevo
                    validacion(Persona1.user, password1,botoLogin)

                }

            }


    }

    fun validacion(nick:String, contra:String,botoLogin:Button) {
             layout = ly_login

            if (nick.equals(usuario, true) && contra.equals(password1, true)) {

                val intent = Intent(this, DatosActivity::class.java)
                    intent.putExtra(LoginActivity.KEY, nombre)
                    intent.putExtra(LoginActivity.KEY2, apellido)
                    intent.putExtra(LoginActivity.KEY3, usuario)
                    intent.putExtra(LoginActivity.KEY4, password1)
                    startActivity(intent)

            }else {
                Toast.makeText(this, "La contrase es incorrecta ", Toast.LENGTH_SHORT).show()
            }

        }

}

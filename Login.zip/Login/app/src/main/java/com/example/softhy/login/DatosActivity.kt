package com.example.softhy.login

import android.app.Activity
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.Snackbar
import android.widget.Button
import android.widget.ShareActionProvider
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_datos.*
import kotlinx.android.synthetic.main.activity_login.*

class DatosActivity : AppCompatActivity() {

    companion object {
        var password = ""
        var PASSWORD = "CONTRA"
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_datos)

        var nombre1 = lbl_nombre
        var apellido = lbl_apellido
        var user = lbl_User2
        var boton = bt_cambioContra

        intent.extras.apply {
            nombre1.text = this.getString(LoginActivity.KEY)
            apellido.text = this.getString(LoginActivity.KEY2)
            user.text = this.getString(LoginActivity.KEY3)
            password= this.getString(LoginActivity.KEY4)
        }


//        boton.setOnClickListener {
//            val intent = Intent(this, CambioContraActivity:: class.java)
//            intent.putExtra(DatosActivity.PASSWORD, password)
//            startActivityForResult(intent, 1)
//        }
        val boton2 =bt_cambioContra2
        boton2.setOnClickListener {
            val intent2 = Intent(this, BotonesActivity::class.java)
            startActivityForResult(intent2, 2)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 1) {
            if (resultCode == Activity.RESULT_OK) {
                val message = data?.getStringExtra(CambioContraActivity.EXTRA_MSG_RESULT)
                message?.let {
                    val snack = Snackbar.make(layout_datos, it, Snackbar.LENGTH_SHORT).show()
                }

            }
        }
        if(requestCode == 2 ) {
            if(resultCode == Activity.RESULT_OK){
                val report = data?.getStringExtra(BotonesActivity.mensaje)
                report?.let{
                    val snack2 = Snackbar.make(layout_datos, it, Snackbar.LENGTH_SHORT).show()
                    Toast.makeText(this, "salio?", Toast.LENGTH_SHORT).show();
                }
            }
        }

    }
}

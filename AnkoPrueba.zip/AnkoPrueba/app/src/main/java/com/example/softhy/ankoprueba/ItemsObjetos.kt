package com.example.softhy.ankoprueba

import android.widget.ImageView


data class ItemsDatos2(var nombre:String, var descrip:String, var precio:String, var imagen:Int)




package com.example.finalapplication.login.presenterLogin

import android.content.Intent
import com.example.finalapplication.login.modelLogin.LoginModel
import com.example.finalapplication.login.mvp.LoginMVP

class LoginPresenter(var view:LoginMVP.View ):LoginMVP.Presenter {
    var model = LoginModel(this)

    override fun datosPersonales(nombre: String, pass: String) {
        model.datosPersonales(nombre,pass) { consulta, respuesta ->
            if (consulta) view.imprimirConfirmacion(respuesta)
            else {
                view.imprimirError(respuesta)
            }
        }
    }
}
package com.example.finalapplication.perfiles.presenter

import com.example.finalapplication.perfiles.model.PerfilModel
import com.example.finalapplication.perfiles.mvp.PerfilMVP

class PerfilPresenter(var view :PerfilMVP.View):PerfilMVP.Presenter {
    var model= PerfilModel(this)

    override fun perdirDatos(ctd: Int) {
        model.envioDatos{
            view.imprimirDatos(it,ctd)
        }
    }
}
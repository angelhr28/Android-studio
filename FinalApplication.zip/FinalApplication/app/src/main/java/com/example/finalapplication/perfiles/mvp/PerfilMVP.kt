package com.example.finalapplication.perfiles.mvp

import com.example.finalapplication.perfiles.model.DataFotos

interface PerfilMVP {
    interface View {
        fun imprimirDatos(lista:MutableList<DataFotos>,ctd:Int)
    }
    interface Presenter{
        fun perdirDatos(ctd : Int)
    }
    interface Model{
        fun envioDatos(solicitud:(MutableList<DataFotos>)->Unit)
    }
}
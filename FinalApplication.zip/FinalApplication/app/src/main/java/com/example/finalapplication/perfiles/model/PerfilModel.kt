package com.example.finalapplication.perfiles.model

import com.example.finalapplication.perfiles.mvp.PerfilMVP

class PerfilModel(var presenter :PerfilMVP.Presenter):PerfilMVP.Model {
    override fun envioDatos( solicitud: (MutableList<DataFotos>) -> Unit) {
        var datosUser = mutableListOf<DataFotos>()
        datosUser.add(DataFotos("Angel", "Joshi","1 mes","chusco","https://sistemas.com/termino/wp-content/uploads/Usuario-Icono.jpg", "https://hips.hearstapps.com/es.h-cdn.co/quoes/images/ser-humano/doga-yoga-para-perros/1442329-1-esl-ES/doga-yoga-para-perros-y-otras-ideas-contra-el-estres-canino.-de-verdad-sirven-de-algo.jpg"))
        datosUser.add(DataFotos("Jose", "Pocho","4 mese ","dowerman","https://sistemas.com/termino/wp-content/uploads/Usuario-Icono.jpg", "https://wakyma.com/blog/wp-content/uploads/2018/03/29095758_1686602754757540_2194112763607908352_n-1024x1024.jpg"))
        datosUser.add(DataFotos("Pedro", "Paco","8 mes","peruano","https://sistemas.com/termino/wp-content/uploads/Usuario-Icono.jpg", "https://hips.hearstapps.com/es.h-cdn.co/mcres/images/mi-casa/terraza-jardines-porche/perros-famosos-instagram/1765916-8-esl-ES/perros-famosos-!en-instagram.jpg"))
        datosUser.add(DataFotos("MIguel", "Perro","5 mes","chusco","https://sistemas.com/termino/wp-content/uploads/Usuario-Icono.jpg", "https://www.okchicas.com/wp-content/uploads/2017/01/Perro-2.jpeg"))
        solicitud(datosUser)
    }
}
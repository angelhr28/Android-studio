package com.example.finalapplication.perfiles.view

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.animation.Animation
import android.view.animation.RotateAnimation
import android.widget.*
import com.example.finalapplication.R
import com.example.finalapplication.perfiles.model.DataFotos
import com.example.finalapplication.perfiles.mvp.PerfilMVP
import com.example.finalapplication.perfiles.presenter.PerfilPresenter
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_perfil.*
import kotlinx.android.synthetic.main.include_datos.*
import android.view.Menu
import android.view.MenuItem


class PerfilActivity : AppCompatActivity() , PerfilMVP.View{
    override fun imprimirDatos(lista: MutableList<DataFotos>,ctd:Int) {
        namePet  =lbl_namePet
        nameUser = lbl_userTIndog
        namePet2 =lbl_pet
        namePet3 = lbl_pet3
        imgPet   = img_pet1_vista
        imgPetB  = img_pet1
        imgUser  = img_user
        edad     = lbl_edad
        raza     = lbl_raza
        namePet.text  = lista[ctd].nombrePet
        namePet2.text = lista[ctd].nombrePet
        namePet3.text = lista[ctd].nombrePet
        nameUser.text = lista[ctd].nombreUser
        edad.text     = lista[ctd].edad
        raza.text     = lista[ctd].raza
        cambioForma(lista[ctd].fotoUser,imgUser )
        cambioForma(lista[ctd].fotoPet,imgPet )
        cambioForma(lista[ctd].fotoPet,imgPetB )
    }

    var contador : Int = 0
    lateinit var imgPet  :ImageView
    lateinit var imgPetB :ImageView
    lateinit var imgUser :ImageView
    lateinit var namePet :TextView
    lateinit var nameUser:TextView
    lateinit var namePet2 :TextView
    lateinit var namePet3:TextView
    lateinit var presenter : PerfilPresenter
    lateinit var btnIconX: ImageButton
    lateinit var btnIconCora: ImageButton
    lateinit var raza:TextView
    lateinit var edad :TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_perfil)

        presenter  =PerfilPresenter(this)
        btnIconX   =btn_fail
        btnIconCora=btn_love
        imgPet = img_pet1_vista
        imgPetB = img_pet1
        imgUser = img_user
        val intent = Intent()
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK

        cambioForma("https://static.alfabetajuega.com/abj_public_files/Alfabetajuega-Perros-Overwatch_2.jpg",imgPet)
        cambioForma("https://static.alfabetajuega.com/abj_public_files/Alfabetajuega-Perros-Overwatch_2.jpg",imgPetB)
        cambioForma("https://ams.educause.edu/eweb/upload/60283746.jpg",imgUser)

        btnIconX.setOnClickListener {
            contador++

            presenter.perdirDatos(contador)
        }
        btnIconCora.setOnClickListener {

            contador++
            presenter.perdirDatos(contador)
        }
        var imageView:ImageView
        imageView = ic_btn_sheet
        rotarImagen(imageView)
        var toolbar = toolBar
        setSupportActionBar(toolbar)
    }
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_toolbar, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        val id = item.getItemId()

        return super.onOptionsItemSelected(item)
    }


    fun cambioForma(foto:String,lugar:ImageView){
        val transformation = com.makeramen.roundedimageview.RoundedTransformationBuilder()
            .borderColor(android.graphics.Color.BLACK)
            .borderWidthDp(4f)
            .cornerRadiusDp(3f)
            .oval(true)
            .build()

        Picasso.get()
            .load(foto)
            .transform(transformation)
            .fit()
            .placeholder(R.drawable.ic_launcher_background)
            .into(lugar)
    }

    fun rotarImagen(view: View) {
        val animation = RotateAnimation(
            0f, 360f,
            RotateAnimation.RELATIVE_TO_SELF, 0.5f,
            RotateAnimation.RELATIVE_TO_SELF, 0.5f
        )

        animation.duration = 2000
        animation.repeatCount = Animation.ABSOLUTE
        animation.repeatMode = Animation.REVERSE
        view.startAnimation(animation)
    }
}

package com.example.finalapplication.perfiles.model

data class DataFotos (var nombreUser:String ,var nombrePet:String,var edad:String ,var raza : String,var fotoUser:String,var fotoPet:String)
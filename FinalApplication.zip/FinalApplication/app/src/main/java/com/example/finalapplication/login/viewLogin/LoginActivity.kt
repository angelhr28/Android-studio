package com.example.finalapplication.login.viewLogin

import android.content.Intent
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.constraint.ConstraintLayout
import android.support.design.widget.Snackbar
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import com.example.finalapplication.root.App
import com.example.finalapplication.perfiles.view.PerfilActivity
import com.example.finalapplication.R
import com.example.finalapplication.login.mvp.LoginMVP
import com.example.finalapplication.login.presenterLogin.LoginPresenter
import kotlinx.android.synthetic.main.activity_main.*


class LoginActivity : AppCompatActivity(), LoginMVP.View {
    lateinit var snackbar :Snackbar
    lateinit var lblUser: EditText
    lateinit var lblPass: EditText
    lateinit var btnLogin: Button
    lateinit var layaoutLogin : ConstraintLayout
    lateinit var presenter :LoginPresenter

    override fun imprimirConfirmacion(mensaje: String) {
        layaoutLogin = ly_login
        snackbar = Snackbar.make(layaoutLogin, mensaje, Snackbar.LENGTH_LONG)
        snackbar.show()
        val intent = Intent(this, PerfilActivity::class.java)
        startActivity(intent)
        Intent.FLAG_ACTIVITY_CLEAR_TOP
    }

    override fun imprimirError(error: String) {
        layaoutLogin = ly_login
        snackbar = Snackbar
            .make(layaoutLogin, error, Snackbar.LENGTH_LONG)
        snackbar.show()
    }

    var prefs = App.prefs!!
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT < 16) {
            window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN)
        }
        setContentView(R.layout.activity_main)
        presenter = LoginPresenter(this)
        btnLogin = bt_login
        btnLogin.setOnClickListener {
            lblUser  = lbl_user
            lblPass  = lbl_password
            presenter.datosPersonales(lblUser.text.toString(), lblPass.text.toString())
            prefs.usuario = lblUser.text.toString().trim()
        }
        if (prefs.verificacion) {
            val intent2 = Intent(this, PerfilActivity::class.java)
            startActivity(intent2)
        }
    }
}

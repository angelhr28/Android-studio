package com.example.finalapplication.login.modelLogin

class DatosUser (val nombre:String = "angel",val apellido:String = "robles",val user:String ,val password:String )

package com.example.finalapplication.root

import android.app.Application
import android.content.Context

class App : Application() {

    companion object {
        var prefs: Preferens? = null
    }

    override fun onCreate() {
        super.onCreate()
        prefs =
                Preferens(applicationContext)
    }
}
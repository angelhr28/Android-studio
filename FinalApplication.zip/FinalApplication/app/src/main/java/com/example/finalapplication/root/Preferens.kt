package com.example.finalapplication.root

import android.content.Context

class Preferens (context: Context){
    val preferens = context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE)

    var verificacion: Boolean
        get() = preferens.getBoolean(PREFERENCES_LOGIN, false)
        set(value)= preferens.edit().putBoolean(PREFERENCES_LOGIN, value).apply()

    var nombre: String
        get() = preferens.getString(PREFERENCES_NOMBRE, "nombre")
        set(value) = preferens.edit().putString(PREFERENCES_NOMBRE, value).apply()

    var apellido: String
        get() = preferens.getString(PREFERENCES_APELLIDO, "apellido")
        set(value) = preferens.edit().putString(PREFERENCES_APELLIDO, value).apply()

    var usuario: String
        get() = preferens.getString(PREFERENCES_USER, "usuario")
        set(value) = preferens.edit().putString(PREFERENCES_USER, value).apply()

    companion object {
        val PREFERENCES_NAME= "name"
        val PREFERENCES_LOGIN= "login"
        val PREFERENCES_NOMBRE= "nombre"
        val PREFERENCES_APELLIDO= "apellido"
        val PREFERENCES_USER= "user"
    }
}
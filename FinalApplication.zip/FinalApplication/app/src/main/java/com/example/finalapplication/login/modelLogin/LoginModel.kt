package com.example.finalapplication.login.modelLogin

import com.example.finalapplication.login.mvp.LoginMVP
import com.example.finalapplication.login.presenterLogin.LoginPresenter
import com.example.finalapplication.root.App

class LoginModel(var presenter:LoginPresenter):LoginMVP.Model {

    var prefs   = App.prefs!!
    val persona = DatosUser("angel", "robles", "angel", "123456")
    var mensaje ="Logeo Exitoso"
    var error   = "Contraseña incorrecta"
    override fun datosPersonales(nombre: String, pass: String, respuesta: (Boolean, String) -> Unit) {
        if (nombre.equals(persona.user, true) && pass.equals(persona.password, true)) {

            prefs.verificacion = true
            prefs.nombre = persona.nombre
            prefs.apellido = persona.apellido
            respuesta(true ,mensaje)
        }else {
            respuesta(false,error)
        }
    }


}
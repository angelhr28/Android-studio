package com.example.finalapplication.login.mvp

import android.content.Intent

interface LoginMVP {
    interface View{
        fun imprimirConfirmacion(mensaje:String)
        fun imprimirError(error:String)
    }
    interface Presenter{
        fun datosPersonales(nombre:String , pass:String)
    }
    interface Model{
        fun datosPersonales(nombre:String , pass:String,respuesta:(Boolean,String)->Unit)
    }
}